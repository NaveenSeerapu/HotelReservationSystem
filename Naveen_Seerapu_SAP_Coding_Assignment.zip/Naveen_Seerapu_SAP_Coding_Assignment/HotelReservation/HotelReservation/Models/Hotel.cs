﻿using System.Collections.Generic;

namespace HotelReservation.Models
{
    /**
    * @author naveenseerapu
    * Hotel has limited number of rooms in it which is equal to the size defined.
    */
    public class Hotel
    {
        public string Name;
        public int Size;
        public List<Room> Rooms;                        //No. of rooms in a hotel should be scalable

        public Hotel(string name, int size)
        {
            this.Name = name;
            this.Size = size;
            Rooms = new List<Room>();
            for (int i = 1; i <= size; i++)
            {
                Rooms.Add(new Room(i));
            }
        }
    }
}
