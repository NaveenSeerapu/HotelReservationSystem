﻿namespace HotelReservation.Validators
{
    /*
    * @author naveenseerapu 
    * RequestValidator static class helps to validates inputs given by the user.
    */
    public static class RequestValidator
    {
        public static bool isValidateReservationRequest(int startDate, int endDate)
        {
            if (startDate < 0 || endDate > 364)
                return false;
            else
                return true;
        }

        public static bool isValidHotelName(string hotelName)
        {
            if (string.IsNullOrEmpty(hotelName) || string.IsNullOrWhiteSpace(hotelName))
                return false;
            else
                return true;
        }
    }
}
