﻿using HotelReservation.Validators;
using System;

namespace HotelReservation.Util
{
    /*
     * @author naveenseerapu 
     * ReaderUtil static class helps to read from the console when user attempts to provide input through command prompt/shell
    */
    public static class ReaderUtil
    {
        public static int ReadDate()
        {
            int date; bool res = false;
            res = int.TryParse(Console.ReadLine(), out date);
            if (res)
                return date;
            else
                return -1;
        }

        public static int ConvertStringToInt(string input)
        {
            int date; bool res = false;
            res = int.TryParse(input, out date);
            if (res)
                return date;
            else
                return -1;
        }

        public static string PromptHotelName()
        {
            string hotelName = string.Empty;
            Console.WriteLine("Please enter the name of the hotel.");
            while (true)
            {
                hotelName = Console.ReadLine();
                bool isValidName = RequestValidator.isValidHotelName(hotelName);
                if (!isValidName)
                {
                    Console.WriteLine("INVALID_HOTEL_NAME_ERROR : Please enter a valid hotel name");
                    continue;
                }
                break;
            }
            return hotelName;
        }

        public static int PromptHotelSize()
        {
            int hotelSize = 0;
            Console.WriteLine("Please enter the size of the hotel.");
            while (hotelSize == 0)
            {
                string strSize = Console.ReadLine();
                if (string.IsNullOrEmpty(strSize) || string.IsNullOrWhiteSpace(strSize))
                {
                    Console.WriteLine("INVALID_HOTEL_SIZE_ERROR: Please enter a valid hotel size.");
                    continue;
                }
                hotelSize = Convert.ToInt32(strSize);
            }
            return hotelSize;
        }
    }
}
