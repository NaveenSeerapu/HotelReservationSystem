﻿using HotelReservation.Models;
using System;
using HotelReservation.Validators;

namespace HotelReservation.Managers
{
    /*
    * @author NaveenSeerapu
    * Reservation Manager class that can shows below behaviors
    * 1. to create hotel and 
    * 2. accept/decline reservation in a hotel for a given start & end dates
    */
    public class ReservationManager
    {

        /*
        * This public method creates a hotel based on the number of rooms user provides
        */
        public Hotel CreateHotel(string hotelName, int hotelSize)
        {
            Hotel hotel = new Hotel(hotelName, hotelSize);
            return hotel;
        }

        /*
        * This public method reserves a room for a given Hotel that prompts start and end dates and returns status of reservation
        * @Parameters hotel (Hotel)
        * @Output Reservation Status string
        */
        public int ReserveRoom(int startDate, int endDate, ref Hotel hotel)
        {
            int roomNumber;
            if (RequestValidator.isValidateReservationRequest(startDate, endDate))
                roomNumber = AcceptOrDeclineRoom(startDate, endDate, ref hotel);
            else
                roomNumber = -1;
            return roomNumber;
        }

        /*
        * This private method is a reusable component that performs single responsibility of checking room availablity for a given hotel.        
        * Below shows the algorithm to return a best selection of room that is available.
        * @Parameters startDate, endDate, hotel
        * @Returns RoomNumber
        */
        private int GetAvailableRoom(int startDate, int endDate, ref Hotel hotel)
        {
            int smallestSpaceAvailableForADateRange = 364;          //This property maintains the length of smallest space available between two existing reservations in all rooms for a requested date range
            int resultRoomNumber = 0;
            int distanceFromNearestOccupiedDate = 364;

            foreach (Room room in hotel.Rooms)
            {
                bool isThisRoomAvailableForDateRange = true;
                for (int i = startDate; i <= endDate; i++)          //Check if the room is already occupied for given date range
                {
                    if (room.DateCalendar[i] == 1)
                    {
                        isThisRoomAvailableForDateRange = false;
                        break;
                    }
                }
                if (isThisRoomAvailableForDateRange)
                {
                    int distanceFromNearestLeft = 0, distanceFromNearestRight = 0, leftTraversalIndex = startDate - 1, rightTraversalIndex = endDate + 1;
                    while (leftTraversalIndex >= 0)
                    {
                        if (room.DateCalendar[leftTraversalIndex] == 0)
                        {
                            distanceFromNearestLeft++;
                            leftTraversalIndex--;
                        }
                        else
                            break;
                    }
                    while (rightTraversalIndex <= 364)
                    {
                        if (room.DateCalendar[rightTraversalIndex] == 0)
                        {
                            distanceFromNearestRight++;
                            rightTraversalIndex++;
                        }
                        else
                            break;
                    }

                    if ((distanceFromNearestLeft + distanceFromNearestRight) <= smallestSpaceAvailableForADateRange)
                    {
                        smallestSpaceAvailableForADateRange = (distanceFromNearestLeft + distanceFromNearestRight);
                        int minDistanceFromAnOccupiedDate = Math.Min(distanceFromNearestLeft, distanceFromNearestRight);

                        if (minDistanceFromAnOccupiedDate < distanceFromNearestOccupiedDate)
                        {
                            distanceFromNearestOccupiedDate = minDistanceFromAnOccupiedDate;
                            resultRoomNumber = room.RoomNumber;
                        }
                    }
                }
            }
            return resultRoomNumber;
        }


        /*
        * This private method is reusable code that accept/decline a room for given range of dates in a hotel
        * @Parameters startDate (integer), endDate (integer), hotel (Hotel)
        */
        private int AcceptOrDeclineRoom(int startDate, int endDate, ref Hotel hotel)
        {
            int roomNumber;
            roomNumber = GetAvailableRoom(startDate, endDate, ref hotel);

            if (roomNumber > 0)
            {
                for (int i = startDate; i <= endDate; i++)
                {
                    hotel.Rooms[roomNumber - 1].DateCalendar[i] = 1;                            //flag all the dates with 1
                }
            }

            return roomNumber;
        }

    }
}







