﻿@author naveenseerapu
Project  =>  HotelReservation:

Please follow these steps to run the program successfully:

1.  Run your application HotelReservation using any of the below commands- (the same path where your exe file is generated)
	
	HotelReservation			->To get an interactive command promt based shell where you need to type in the commands
	HotelReservation file_input.txt		->It will read the commands from input file which can be passed in as an argument(testing is covered here.)

	1. e.g. C:\Users\nseerapu\source\repos\HotelReservation\HotelReservation\bin\Debug\netcoreapp3.1>HotelReservation
	2. e.g. C:\Users\nseerapu\source\repos\HotelReservation\HotelReservation\bin\Debug\netcoreapp3.1>HotelReservation file_input.txt

	Note: for second scenario, you must ensure you copied this file from solution folder to build/debug folder.
