﻿using HotelReservation.Models;
using System;
using HotelReservation.Validators;

namespace HotelReservation.Managers
{
    /*
    * @author NaveenSeerapu
    * Reservation Manager class that can shows below behaviors
    * 1. to create hotel and 
    * 2. accept/decline reservation in a hotel for a given start & end dates
    */
    public class ReservationManager
    {

        /*
        * This public method creates a hotel based on the number of rooms user provides
        */
        public Hotel CreateHotel(string hotelName, int hotelSize)
        {
            Hotel hotel = new Hotel(hotelName, hotelSize);
            return hotel;
        }

        /*
        * This public method reserves a room for a given Hotel that prompts start and end dates and returns status of reservation
        * @Parameters hotel (Hotel)
        * @Output Reservation Status string
        */
        public int ReserveRoom(int startDate, int endDate, ref Hotel hotel)
        {
            int roomNumber;
            if (RequestValidator.isValidateReservationRequest(startDate, endDate))
                roomNumber = AcceptOrDeclineRoom(startDate, endDate, ref hotel);
            else
                roomNumber = -1;
            return roomNumber;
        }

        /*
        * This private method is a reusable component that performs single responsibility of checking room availablity for a given hotel.        
        * Below shows the algorithm to return a best selection of room that is available.
        * @Parameters startDate, endDate, hotel
        * @Returns RoomNumber
        */
        private int GetAvailableRoom(int startDate, int endDate, ref Hotel hotel)
        {
            int smallestSpaceAvailableForADateRange = 364;          //This property maintains the length of smallest space available between two existing reservations in all rooms for a requested date range
            int resultRoomNumber = 0;
            int distanceFromNearestOccupiedDate = 364;

            foreach (Room room in hotel.Rooms)                      //Check in the existing rooms created so far if there is a valid slot available
            {
                bool isThisRoomAvailableForDateRange = true;
                for (int i = startDate; i <= endDate; i++)          //Check if current room is already occupied for given date range
                {
                    if (room.DateCalendar[i] == 1)
                    {
                        isThisRoomAvailableForDateRange = false;
                        break;
                    }
                }
                if (isThisRoomAvailableForDateRange)                //If current room is available, get the outbound non-reserved area around the given slot within the rooms
                {
                    int distanceFromNearestLeft = 0, distanceFromNearestRight = 0, leftTraversalIndex = startDate - 1, rightTraversalIndex = endDate + 1;
                    while (leftTraversalIndex >= 0)
                    {
                        if (room.DateCalendar[leftTraversalIndex] == 0)
                        {
                            distanceFromNearestLeft++;
                            leftTraversalIndex--;
                        }
                        else
                            break;
                    }
                    while (rightTraversalIndex <= 364)
                    {
                        if (room.DateCalendar[rightTraversalIndex] == 0)
                        {
                            distanceFromNearestRight++;
                            rightTraversalIndex++;
                        }
                        else
                            break;
                    }

                    if ((distanceFromNearestLeft + distanceFromNearestRight) <= smallestSpaceAvailableForADateRange)        //If outbound area of current is smaller than previous visited room, select current room
                                                                                                                            //If outbound area is same in two different existing rooms,
                                                                                                                            //then choose the room that is near to an existing reservation in the calendar 
                                                                                                                            //so that maximum space for a room is always kept for new reservation 
                    {
                        smallestSpaceAvailableForADateRange = (distanceFromNearestLeft + distanceFromNearestRight);
                        int minDistanceFromAnOccupiedDate = Math.Min(distanceFromNearestLeft, distanceFromNearestRight);

                        if (minDistanceFromAnOccupiedDate < distanceFromNearestOccupiedDate)
                        {
                            distanceFromNearestOccupiedDate = minDistanceFromAnOccupiedDate;
                            resultRoomNumber = room.RoomNumber;
                        }
                    }
                }
            }

            if (resultRoomNumber == 0 && hotel.Rooms.Count < hotel.Size)     //if existing created rooms cannot fulfil a reservation then new room will be created within the specified size of the hotel
            {           
                resultRoomNumber = CreateRoom(ref hotel);
            }
            return resultRoomNumber;
        }


        /*
        * This private method is reusable code that accept/decline a room for given range of dates in a hotel
        * @Parameters startDate (integer), endDate (integer), hotel (Hotel)
        */
        private int AcceptOrDeclineRoom(int startDate, int endDate, ref Hotel hotel)
        {
            int roomNumber;
            roomNumber = GetAvailableRoom(startDate, endDate, ref hotel);

            if (roomNumber > 0)
            {
                for (int i = startDate; i <= endDate; i++)
                {
                    hotel.Rooms[roomNumber - 1].DateCalendar[i] = 1;                            //flag all the dates with 1
                }
            }

            return roomNumber;
        }


        /*@naveenseerapu New code added 07-FEB-2021 to optimize time and complexity*/
        /*This private method creates a new room within the size of hotel when existing rooms cannot suffice the reservation need*/
        private int CreateRoom(ref Hotel hotel)
        {
            int noOfExistingRooms = hotel.Rooms.Count;
            hotel.Rooms.Add(new Room(noOfExistingRooms + 1));
            return noOfExistingRooms + 1;
        }

    }
}







