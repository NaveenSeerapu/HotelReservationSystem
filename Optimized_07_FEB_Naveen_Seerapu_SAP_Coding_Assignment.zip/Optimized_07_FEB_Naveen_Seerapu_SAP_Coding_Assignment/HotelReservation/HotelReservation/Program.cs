﻿using System;
using HotelReservation.Managers;
using HotelReservation.Models;
using System.IO;
using HotelReservation.Enums;
using HotelReservation.Util;


namespace HotelReservation
{
    public class Program
    {
        public static void Main(string[] args)
        {
            string[] inputCommands;

            try
            {
                ReservationManager reservationManager = new ReservationManager();
                Hotel hotel = null;
                string hotelName = string.Empty;
                int hotelSize;

                int roomNumber;

                if (args.Length > 0)                                       //If input is provided from command prompt as 
                                                                           //argument of main method i.e., the name of text document 
                {
                    inputCommands = File.ReadAllLines(args[0]);

                    for (int i = 0; i < inputCommands.Length; i++)
                    {
                        string[] currentCmdArray = inputCommands[i].Split(" ");

                        Command comm = CommandUtil.FindCommand(currentCmdArray[0]);

                        if (comm == Command.INVALID_INPUT)
                        {
                            PrintUtil.PrintInvalidInput();
                            return;
                        }

                        switch (comm)
                        {
                            case Command.CREATE_HOTEL:
                                hotelName = currentCmdArray[1];
                                hotelSize = ReaderUtil.ConvertStringToInt(currentCmdArray[2]);
                                hotel = reservationManager.CreateHotel(hotelName, hotelSize);
                                PrintUtil.PrintHotelCreated(hotelName);
                                continue;
                            case Command.RESERVE_A_ROOM:
                                int startDate = ReaderUtil.ConvertStringToInt(currentCmdArray[1]);
                                int endDate = ReaderUtil.ConvertStringToInt(currentCmdArray[2]);
                                roomNumber = reservationManager.ReserveRoom(startDate, endDate, ref hotel);
                                PrintUtil.PrintReservationStatus(roomNumber);
                                continue;
                            case Command.EXIT:
                                break;
                            default:
                                break;
                        }

                        break;
                    }
                }
                else                                                       //Interactive command prompt 
                                                                           //inputs are taken manually from the command prompt given by the user
                {
                    int optionNo, startDate, endDate;
                    hotelName = ReaderUtil.PromptHotelName();
                    hotelSize = ReaderUtil.PromptHotelSize();
                    hotel = reservationManager.CreateHotel(hotelName, hotelSize);
                    PrintUtil.PrintHotelCreated(hotelName);
                    while (true)
                    {
                        optionNo = PrintUtil.PrintMenu();
                        if (optionNo == (int)Command.RESERVE_A_ROOM)
                        {
                            PrintUtil.PrintStartDate();
                            startDate = ReaderUtil.ReadDate();
                            PrintUtil.PrintEndDate();
                            endDate = ReaderUtil.ReadDate();
                            roomNumber = reservationManager.ReserveRoom(startDate, endDate, ref hotel);
                            PrintUtil.PrintReservationStatus(roomNumber);
                            continue;
                        }
                        else
                            break;
                    }
                }
                Console.ReadKey();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }
}
