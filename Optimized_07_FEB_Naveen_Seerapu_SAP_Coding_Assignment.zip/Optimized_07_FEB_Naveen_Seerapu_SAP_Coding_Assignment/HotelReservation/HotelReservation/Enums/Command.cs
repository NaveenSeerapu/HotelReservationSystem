﻿using System;

namespace HotelReservation.Enums
{
    public enum Command
    {
        CREATE_HOTEL,
        RESERVE_A_ROOM,
        EXIT,
        INVALID_INPUT
    };
}
