﻿namespace HotelReservation.Models
{
    
    /*
     * @author naveenseerapu
     * Room class for details of a room
    */
    public class Room
    {
        public readonly int RoomNumber;
        public int[] DateCalendar;               //Scalable date range is not required in this scenario as it is limited for 365 days
        public Room(int roomNumber)
        {
            this.RoomNumber = roomNumber;
            this.DateCalendar = new int[365];
            for (int i = 0; i < 365; i++)
            {
                this.DateCalendar[0] = 0;        //Fill with zeroes by default
            }
        }
    }
}
