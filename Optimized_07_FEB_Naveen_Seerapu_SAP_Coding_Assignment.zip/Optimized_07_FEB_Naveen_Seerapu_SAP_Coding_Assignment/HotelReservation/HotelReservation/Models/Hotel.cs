﻿using System.Collections.Generic;

namespace HotelReservation.Models
{
    /**
    * @author naveenseerapu
    * Hotel has limited number of rooms in it which is equal to the size defined.
    */
    public class Hotel
    {
        public string Name;
        public int Size;
        public List<Room> Rooms;                        //No. of rooms in a hotel should be scalable

        public Hotel(string name, int size)
        {
            this.Name = name;
            this.Size = size;
            Rooms = new List<Room>();

            /* @NaveenSeerapu 07_FEB_2021 - commented out below piece of code to avoid memory utilization before hand
             * This improves the time traversal as well as memory utilization
             */
            /*
            for (int i = 1; i <= size; i++)
            {
                Rooms.Add(new Room(i));
            }
            */
        }

    }
}
