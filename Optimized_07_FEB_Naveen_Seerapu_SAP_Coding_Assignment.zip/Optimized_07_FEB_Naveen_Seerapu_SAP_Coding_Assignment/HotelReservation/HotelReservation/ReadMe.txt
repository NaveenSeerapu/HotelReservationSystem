﻿@author naveenseerapu
Project  =>  HotelReservation:

Please follow these steps to run the program successfully:

1.  Extract HotelReservation.zip

2.  Open command prompt/terminal, Go to the directory HotelReservation
	e.g. C:\Users\nseerapu\source\repos\HotelReservation\>

3. Ensure dotnet cli and .Net Core are installed on the machine.

4.  Run the command "dotnet build" for downloading the dependenies and build the project.
	e.g. C:\Users\nseerapu\source\repos\HotelReservation\>dotnet build

5.  Once the build is successful, the above command creates the required build artifacts, dll and executable file. Go to the path as below and check if they are created or not
	C:\Users\nseerapu\source\repos\HotelReservation\HotelReservation\bin\Debug\netcoreapp3.1

6.  Go to HotelReservation Parent folder and copy the file_input.txt file to above path where your exe file exists. You may use below
	e.g. copy C:\Users\nseerapu\source\repos\HotelReservation\HotelReservation\file_input.txt  C:\Users\nseerapu\source\repos\HotelReservation\HotelReservation\bin\Debug\netcoreapp3.1 

5.  Run your application HotelReservation using any of the below commands- (the same path where your exe file is generated)
	
	HotelReservation					->To get an interactive command promt based shell where you need to type in the commands
	HotelReservation file_input.txt		->It will read the commands from input file which can be passed in as an argument(testing is covered here.)

	1. e.g. C:\Users\nseerapu\source\repos\HotelReservation\HotelReservation\bin\Debug\netcoreapp3.1>HotelReservation
	2. e.g. C:\Users\nseerapu\source\repos\HotelReservation\HotelReservation\bin\Debug\netcoreapp3.1>HotelReservation file_input.txt

	Note: for second scenario, you must ensure you copied this file from solution folder to build/debug folder.


Note: Unittesting is not implemented for this but automated testing is done using file_input.txt. This zip file already contains
	  built project. There is no need of rebuilding the project.