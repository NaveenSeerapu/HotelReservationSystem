﻿using System;
using HotelReservation.Enums;

namespace HotelReservation.Util
{
    /*
     * @author naveenseerapu 
     * CommandUtil static class helps to read from the file_input.txt
    */
    public static class CommandUtil
    {
        public static Command FindCommand(string command)
        {
            foreach (Command comm in Enum.GetValues(typeof(Command)))
            {
                if (comm.ToString().ToLower() == command.ToLower())
                    return comm;
            }
            return Command.INVALID_INPUT;
        }

    }

}
