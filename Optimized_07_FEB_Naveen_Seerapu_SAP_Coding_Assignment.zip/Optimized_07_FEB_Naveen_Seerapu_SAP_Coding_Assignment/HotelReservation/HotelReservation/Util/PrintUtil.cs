﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HotelReservation.Util
{
    public static class PrintUtil
    {
        public static void PrintReservationStatus(int roomNumber)
        {
            if (roomNumber > 0)
                Console.WriteLine ("Accept - Room Number:" + roomNumber);
            else
                Console.WriteLine("Decline");
        }

        public static void PrintInvalidInput()
        {
            Console.WriteLine("Please provide a correct input command in the text file.");
        }

        public static void PrintHotelCreated(string hotelName)
        {
            Console.WriteLine();
            Console.WriteLine("Hotel " + hotelName + " Created");
        }
        public static int PrintMenu()
        {
            Console.WriteLine("\nChoose one of the below options:\n1. Reserve a room\n2. Exit");
            int optionNo; bool res = false;
            res = int.TryParse(Console.ReadLine(), out optionNo);
            if (res)
                return optionNo;
            else
                return -1;

        }

        public static void PrintStartDate()
        {     
            Console.WriteLine("Please enter start date (0-364)" );
        }

        public static void PrintEndDate()
        {
            Console.WriteLine("Please enter end date (0-364)");
        }

    }
}
